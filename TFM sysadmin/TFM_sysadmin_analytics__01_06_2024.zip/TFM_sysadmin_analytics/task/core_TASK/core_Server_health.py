import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from plg_CUSTOM.CMD_CENTOS import * 

from plg_CUSTOM.plg_Server_info import * 
from plg_TFM.plg_SSH import *   
from core_TASK.core_Sqlite import * 
from core_TASK.core_Alert_email import * 
from plg_TFM.plg_TXT import * 


class Server_health:
        
   def Log_server_health (self,server_ip, SSH_username, SSH_password):
      LIST_health=[]
      print ("Log_server_health is running")
      server=SSH_into_server(server_ip, SSH_username, SSH_password)
      if server :
         SqliteTasksObj= Sqlite_tasks() 
         dbname=SqliteTasksObj.Setup_log_db("/DB_check_server/",'server_health')

         ping_response=self._FetchLog_ping(server) 
         uptime_response=self._FetchLog_uptime(server)

         LIST_health=[server_ip,ping_response,uptime_response,dbname]
         SqliteTasksObj.Log_server_health_in_db(dbname,LIST_health)
      
      return LIST_health
   
   def _FetchLog_ping(self,server):
       
      ip_infos= server.get_transport().getpeername() #return tuple
      server_ip=ip_infos[0]
      command = cmd_Sys_0 + server_ip
      ping_response =run_server_command(server,command)
      
      if str(ping_response).find('10 received') > 0:
         issue=0 #no issue do nothing
      elif str(ping_response).find('0 received') > 0:     
         msg = "Subject: Server ip = {}\n\n The name or service NOT found. Server ping result = {}\n".format(server_ip,ping_response )    
         self._Send_Alert_Emails(server_ip,msg)
         ping_response="Server is unavailable"
      
      file_name=server_ip+'_server_health.txt'
      log_server_health_text_file = FOLDER_PATH_RAW +  'RAW_check_server/' +  file_name 
      
      date_time=get_date_time()
      content='Log Time : '+str(date_time)+'\n'  
      LIST_content=[content,ping_response]
     
      write_to_TXT_file_2(log_server_health_text_file,LIST_content)
      
      return ping_response
   
   def _FetchLog_uptime(self,server):
       
      ip_infos= server.get_transport().getpeername()  
      server_ip=ip_infos[0]
      command = cmd_Sys_1 
      uptime_response =run_server_command(server,command)
      file_name=server_ip+'_server_uptime.txt'
      log_server_uptime_text_file = FOLDER_PATH_RAW +  'RAW_check_server/' +  file_name 
      
      date_time=get_date_time()
      content='Log Time : '+str(date_time)+'\n'  
      LIST_content=[content,uptime_response]
     
      write_to_TXT_file_2(log_server_uptime_text_file,LIST_content)
      
      return uptime_response

   def _Send_Alert_Emails(self,msg):
      AlertEmailObj=Alert_email()
      try :
                 
         AlertEmailObj.ALERT_Ym_sf6684()[0].sendmail(from_sf6684, "sf6684@yahoo.com", msg)
         AlertEmailObj.ALERT_Aol_shanef1788()[0].sendmail(from_aol_shanef1788, "sf6684@yahoo.com", msg)
         AlertEmailObj.ALERT_Aol_shanef1788()[0].sendmail(from_aol_shanef1788, "shanef1788@aol.com", msg)
      except Exception as e:
          print  ( f'Alert Email failed : {str(e)} '  ) 