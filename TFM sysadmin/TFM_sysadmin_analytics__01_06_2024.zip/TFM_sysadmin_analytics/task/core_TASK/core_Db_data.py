import sys
import os
sys.path.append('../plg_CUSTOM/') 
sys.path.append('../plg_TFM/') 

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from plg_CUSTOM.plg_Server_info import *  
from core_TASK.core_Sqlite import * 
from plg_TFM.plg_TXT import * 


class DB_data:
   
   def Log_db_data(self,csv_path,db_file_path): 
      db_row_count_text_file =''
      if  os.path.exists(csv_path)==True  : 
         if  os.path.exists(db_file_path)==True  : 
            Dir_path = os.path.dirname(os.path.abspath(__file__))
            cron_command_directory=os.path.dirname(Dir_path)
            cron_command_file=cron_command_directory+"/TFM_task_router.py"
            cron_task_function='Schedule_log_db_data'
            args='a_0'+csv_path+'a_1'+db_file_path
            file_name=csv_path.replace('.csv','_counts.txt')  
            file_name=os.path.basename(file_name)
            db_row_count_text_file = FOLDER_PATH_RAW +  'RAW_check_database/' +  file_name  
            Setup_cronjob_byminutes(cron_command_file,cron_task_function,args, LOG_DB_DATA_INTERVEL,'ScheduleLogDbData') 
           
      return db_row_count_text_file


   ### *** SCHEDULE LOG DB DATA ***
   def Schedule_log_db_data (self,csv_path,db_file_path):
      SqliteTasksObj= Sqlite_tasks()
      dbname=SqliteTasksObj.Setup_log_db("/DB_check_database/",'db_row_count')
      
      LIST_line = read_TXT_file(db_file_path)

      file_name=csv_path.replace('.csv','_counts.txt')  
      file_name=os.path.basename(file_name)
      db_row_count_text_file = FOLDER_PATH_RAW +  'RAW_check_database/' +  file_name 
      
      date_time=get_date_time()
      
      log_time_content='Log Time : '+str(date_time)+'\n'
      write_to_TXT_file_1(db_row_count_text_file,log_time_content)
      count = 0
      
      infoLIST=CSV_reader(csv_path)
      for i in range(len(infoLIST)):
         if i>0 :
            row_string= infoLIST[i][0] 
            arr=row_string.split(',')
            server_batch_num= arr[0]
            server_type= arr[1]
            server_ip= arr[2]
            SSH_username= arr[3]
            SSH_password= arr[4]
            server=SSH_into_server(server_ip,SSH_username,SSH_password) 
            serverinfo_content='Server : '+str(server_ip)+'\n'
            write_to_TXT_file_1(db_row_count_text_file,serverinfo_content)
               
            # Strips the newline character
            for line in LIST_line:
               count += 1
               db_path=  line.strip() #this is full path of database in file 
                  
               dbpath_content='Database : '+db_path +'\n'
               write_to_TXT_file_1(db_row_count_text_file,dbpath_content)

               command ="sqlite3 "+ db_path + " .tables"
               response=run_server_command(server,command)
                   
               tablelists=response.split()

               command ="sqlite3 "+ db_path + " <<'END_SQL'\n"
               command+=".timeout 2000\n"
               for table in tablelists:
                  command+="SELECT COUNT(*) FROM "+table+";\n"
                           
               command+="END_SQL"
                  #print(command)
               response=run_server_command(server,command)
               rows_counts_lists=response.splitlines()
               total=0    
               for rows_count in rows_counts_lists:
                  total+=int(rows_count)
                  
               row_content='Rows Count : '+str(total) +'\n\n\n'
               write_to_TXT_file_1(db_row_count_text_file,row_content) 
               output=[server_ip,db_path,total]
               SqliteTasksObj.Log_db_row_count_in_db(dbname,output)
               print(total) 
         



