import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
 
from plg_CENTOS.plg_c_System_info import *
#from plg_TFM.plg_SSH import *  #plg_CENTOS already contain ssh
from plg_CUSTOM.plg_Server_info import *  
from core_TASK.core_Sqlite import * 
from core_TASK.core_Alert_email import * 
from plg_TFM.plg_TXT import * 


class Server_usage:
   def Log_server_usage (self,server_ip, SSH_username, SSH_password): 
      print ("Log_server_usage is running")
      LIST_server_usage=[]
      server =SSH_into_server(server_ip, SSH_username, SSH_password)
      if server:
         SqliteTasksObj= Sqlite_tasks() 
         dbname=SqliteTasksObj.Setup_log_db("/DB_check_server/","server_usage")

         cpu_usage_specs=self._FetchLog_cpu_usage(server) 
         disk_usage_specs=self._FetchLog_disk_usage(server)
         memory_usage_specs=self._FetchLog_memory_usage(server) 
         process_usage_specs=self._FetchLog_process_usage(server)
         
         CPU_usage = re.findall(r'\d*\.?\d+',cpu_usage_specs)
         RAM_usage = re.findall(r'\d*\.?\d+',memory_usage_specs)
         DISK_usage = re.findall(r'\d*%', disk_usage_specs )
            
         print ( 'CPU usage =',CPU_usage, flush=True)  #get numbers with decimal places
         print ( 'RAM usage =',RAM_usage, flush=True ) #get numbers with decimal places
         print ( 'DISK usage =',DISK_usage, flush=True) #get precentage numbers
      
         CPU_usage = list(map(float, CPU_usage))
         RAM_usage = list(map(float, RAM_usage))
         
         #remove all % signs from Disk_usage values 
         DISK_usage.remove('%')
         DISK_usage_num = []
         
         for x in DISK_usage:      
            DISK_usage_num.append(x.rstrip('%'))  
         
         print('DISK_usage_num = ', DISK_usage_num)
         DISK_usage_num = list(map(int, DISK_usage_num)) #DISK_usage_num is the new list without % signs
         
         ### The sums are here, we can manipulate the sums by adding or subtracting the values       
         sum_CPU_usage = sum(CPU_usage)
         sum_RAM_usage = sum(RAM_usage) 
         sum_DISK_usage_num = sum(DISK_usage_num)

         print('sum_CPU_usage ' + str(sum_CPU_usage))
         print('sum_RAM_usage '+ str(sum_RAM_usage))
         print('sum_DISK_usage_num '+ str(sum_DISK_usage_num))
         if (sum_CPU_usage >=70):
            print ('Total CPU usage = ', sum_CPU_usage, ' is MORE than 70 percent')

            msg = "Subject: Server ip = {}\n\n Total CPU usage is MORE than 70%. Total CPU usage = {}\n percent".format(server_ip, sum_CPU_usage)  
            self._Send_Alert_Emails(msg) 
         
         else:
               print  ( server_ip,' Total CPU usage = ', sum_CPU_usage, ' is LESS than 70 percent') 

         
         if (sum_RAM_usage >=70):

            print (server_ip, ' Total RAM usage = ', sum_RAM_usage, ' is MORE than 70 percent')
            msg = "Subject: Server ip = {}\n\n Total RAM usage is MORE than 70%. Total RAM usage = {}\n percent".format(server_ip, sum_RAM_usage)        
            self._Send_Alert_Emails(msg)
               
             
               
         else:
            print  (server_ip, ' Total RAM usage = ', sum_RAM_usage, ' is LESS than 70 percent') 
            
                              
         if (sum_DISK_usage_num >=70):
            print (server_ip, ' Total DISK usage = ', sum_DISK_usage_num, ' is MORE than 70 percent')
            msg = "Subject: Server ip = {}\n\n Total DISK usage is MORE than 70%. Total DISK usage = {}\n percent".format(server_ip, sum_DISK_usage_num)        
            self._Send_Alert_Emails(msg)  
               
         else:
            print(server_ip, ' Total DISK usage = ', sum_DISK_usage_num, ' is LESS than 70 percent') 
            
         
           

      LIST_server_usage=[server_ip,cpu_usage_specs,disk_usage_specs,memory_usage_specs,process_usage_specs,dbname]
      SqliteTasksObj.Log_server_usage_in_db(dbname,LIST_server_usage)
      
      return LIST_server_usage  
         
   def _FetchLog_cpu_usage(self,server): 
      ip_infos= server.get_transport().getpeername() #return tuple
      server_ip=ip_infos[0]   

      command=get_usage_CPU("1")
      cpu_usage_specs=run_server_command(server,command)
         
      file_name=server_ip+'_cpu_usage.txt'
      cpu_specs_text_file = FOLDER_PATH_RAW +  'RAW_check_server/' +  file_name 

      delete_TXT_file(cpu_specs_text_file)          
      date_time=get_date_time()
      content='Log Time : '+str(date_time)+'\n' 
      LIST_content=[content,cpu_usage_specs]
      write_to_TXT_file_2(cpu_specs_text_file,LIST_content)

      return cpu_usage_specs
   
   def _FetchLog_disk_usage(self,server): 
      ip_infos= server.get_transport().getpeername()  
      server_ip=ip_infos[0]  
      command=get_usage_DISK("4")
       
      disk_usage_specs=run_server_command(server,command)
         
      file_name=server_ip+'_disk_usage.txt'
      log_disk_specs_text_file = FOLDER_PATH_RAW +  'RAW_check_server/' +  file_name 

      delete_TXT_file(log_disk_specs_text_file)          
      date_time=get_date_time()
      content='Log Time : '+str(date_time)+'\n' 
      LIST_content=[content,disk_usage_specs]
      write_to_TXT_file_2(log_disk_specs_text_file,LIST_content)
      
      return disk_usage_specs
   
   def _FetchLog_memory_usage(self,server): 
        
      ip_infos= server.get_transport().getpeername() #return tuple
      server_ip=ip_infos[0]  
      command=get_usage_RAM("0")
      memory_usage_specs=run_server_command(server,command)
      file_name=server_ip+'_memory_usage.txt'
      log_memory_specs_text_file = FOLDER_PATH_RAW +  'RAW_check_server/' +  file_name 
         

      delete_TXT_file(log_memory_specs_text_file)          
      date_time=get_date_time()
      content='Log Time : '+str(date_time)+'\n' 
      LIST_content=[content,memory_usage_specs]
      write_to_TXT_file_2(log_memory_specs_text_file,LIST_content)
   
      return memory_usage_specs

   def _FetchLog_process_usage(self,server): 
      ip_infos= server.get_transport().getpeername() #return tuple
      server_ip=ip_infos[0]
      command=get_usage_RAM("1")
      process_usage_specs=run_server_command(server,command)
         
      file_name=server_ip+'_process_usage.txt'
      log_process_using_memory_text_file = FOLDER_PATH_RAW +  'RAW_check_server/' +  file_name          

      delete_TXT_file(log_process_using_memory_text_file)          
      date_time=get_date_time()
      content='Log Time : '+str(date_time)+'\n' 
      LIST_content=[content,process_usage_specs]
      write_to_TXT_file_2(log_process_using_memory_text_file,LIST_content)
      
      return process_usage_specs

   def _Send_Alert_Emails(self,msg):
      AlertEmailObj=Alert_email()
      try:      

            AlertEmailObj.ALERT_Ym_sf6684()[0].sendmail(from_sf6684, "sf6684@yahoo.com", msg)
            AlertEmailObjALERT.Aol_shanef1788()[0].sendmail(from_aol_shanef1788, "sf6684@yahoo.com", msg)
            AlertEmailObj.ALERT_Aol_shanef1788()[0].sendmail(from_aol_shanef1788, "shanef1788@aol.com", msg)

      except Exception as e:
            print  ( f'Alert Email failed : {str(e)} '  ) 