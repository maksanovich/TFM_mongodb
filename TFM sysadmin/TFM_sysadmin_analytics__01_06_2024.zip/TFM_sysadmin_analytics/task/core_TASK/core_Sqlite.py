import sys
import os
import subprocess
import tempfile

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from plg_CUSTOM.plg_Server_info import *  
from plg_TFM.plg_DB_Sqlite import * 


class Sqlite_tasks:

   ### *** SETUP LOG DB ***
   def Setup_log_db(self,dbpath,dbfor):
      folder=os.path.abspath(FOLDER_PATH_COOKED+dbpath)
      
      if os.path.exists(folder)==True:
         LIST_alldbfiles=self.Find_db_files(folder)
         fileNameStartsWith="LOG_"
         dblogpath=''
         name=self.Get_log_dbname(LIST_alldbfiles,fileNameStartsWith)
         
         if name!='':
               dblogpath=folder+"/"+name+".db"
               if os.path.exists(dblogpath)==False: #db does not exists
                  self.Create_db_Sysadmin(dblogpath,dbfor)
               else: #db already exists
                  db_size=self.Check_db_size(dblogpath) #check size
                  
                  if db_size>=104857600 : #if size is greater than 100 mb create new log db
                     name=Get_log_dbname(LIST_alldbfiles,fileNameStartsWith,True) 
                     
                  dblogpath=folder+"/"+name+".db"
                  self.Create_db_Sysadmin(dblogpath,dbfor)  

                  
      else:
         print ("Database path " + folder +" does not exist")                
      return  dblogpath 

   ### *** GET LOG DBNAME *** 
      
   def Get_log_dbname(self,LIST_files,pattern,isNext=False):
      numbers=[]
      for file in LIST_files:
         names=os.path.splitext(os.path.basename(file))
         name=names[0]
         ext=names[1]
         name=name.replace(pattern,'')
         number=int(name)
         numbers.append(number)
      max_index=0
      if len(numbers)>0:
         max_index=max(numbers)
      if isNext==True:
         max_index+1    
      next_name=pattern+str(max_index) 
      return next_name

   ### *** Find db files *** 
   def Find_db_files(self,folder):
      
      try:
         # Use subprocess to execute the ls command and get the output
         if os.name == 'posix':
               # Unix-based system
               command = ['ls', folder]
         elif os.name == 'nt':
               # Windows system
               command = ['cmd', '/c', 'dir', folder, '/b']
         else:
               raise OSError("Unsupported operating system") 
         
         files=[]
         if sys.version_info >= (3, 7):
               # Code for Python 3.7 and later
               result = subprocess.run(command, capture_output=True, text=True, check=True)
               files = result.stdout.split('\n')
         else:
               # Code for Python 3.6 and earlier
               result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
               stdout = result.stdout.decode('utf-8')
               files = stdout.split('\n')
         
         
         # Filter for files that end with .db
         LIST_db_files = [file for file in files if file.endswith('.db')]
         return LIST_db_files
      except subprocess.CalledProcessError as e:
         print("Error while executing ls command: {e}")
         return []
      except FileNotFoundError:
         print("folder" + folder + " does not exist.")
         return [] 
      
      idcolumn=table+"_id"
      dbname_with_path=os.path.abspath(dbname_with_path) 
      command ="sqlite3 "+ dbname_with_path + " <<'END_SQL'\n"
      command+=".timeout 2000\n"
      command+="SELECT * FROM "+table+" order by "+idcolumn+" DESC limit 0,"+limit+" ;\n"
      command+="END_SQL"
      #print(command)
      response=run_server_command(server,command)
      return response 

   ### *** EXECUTE SQLITE COMMAND ***
   def execute_sqlite_command(self,db_path, sql_commands):
      db_path=db_path.replace(os.sep, '/')
      try:
         # Create a temporary file to hold the SQL commands
         with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.sql') as temp_sql_file:
               temp_sql_file.write(sql_commands)
               temp_sql_file_path = temp_sql_file.name
               temp_sql_file_path=temp_sql_file_path.replace(os.sep, '/')
         # Determine the appropriate command based on the operating system
         if os.name == 'posix':
               # Unix-based system
               command = ['sqlite3', db_path, f'.read {temp_sql_file_path}']
         elif os.name == 'nt':
               # Windows system
               command = ['sqlite3', db_path, f'.read "{temp_sql_file_path}"']
         else:
               raise OSError("Unsupported operating system")

         output=''
         # Execute the command using subprocess
         
         if sys.version_info >= (3, 7):
               result = subprocess.run(command, capture_output=True, text=True, check=True)
               output= result.stdout
         else:
               # Code for Python 3.6 and earlier
               result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
               output= result.stdout.decode('utf-8')
      
         # Return the output
         return output
         
      except subprocess.CalledProcessError as e:
         print(f"Error while executing SQLite command: {e}")
         return e.output
      finally:
         # Clean up the temporary file
         if 'temp_sql_file_path' in locals() and os.path.exists(temp_sql_file_path):
               os.remove(temp_sql_file_path)
   
   ### *** CHECK DB SIZE ***
   def Check_db_size(self,db_path):
      
      sql_commands = """
      PRAGMA page_count;
      PRAGMA page_size;
      """
      output = self.execute_sqlite_command(db_path, sql_commands)
      dbsizes=output.splitlines()
      page_count =0.0
      page_size =0.0
      if len(dbsizes) > 0:
         page_count = int(dbsizes[0]) 
            
      if len(dbsizes) > 1:    
         page_size = int(dbsizes[1])  
         
      bytes_size= page_count * page_size 
      #megabytes_size = round((bytes_size / (1024 * 1024)) ,2)
      return bytes_size


   ### *** CREATE DB SYSADMIN ***
   def Create_db_Sysadmin (self,dbname_with_path,dbfor):
      
      if dbfor=='server_specs':
         sqlite_create_file (dbname_with_path, TBL_create_Log_server_specs)
      
      if dbfor=='server_usage':  
         sqlite_create_file (dbname_with_path, TBL_create_Log_server_usage) 

      if dbfor=='server_health':    
         sqlite_create_file (dbname_with_path, TBL_create_Log_server_health) 

      if dbfor=='url_status':
         sqlite_create_file (dbname_with_path, TBL_create_Log_url_status) 

      if dbfor=='db_row_count':
         sqlite_create_file (dbname_with_path, TBL_create_DB_row_count) 
      
      

   ### *** LOG SERVER SPECS IN DB ***
   def Log_server_specs_in_db(self,dbname_with_path,data):

      date_time=get_date_time()
      server_ip=data[0]
      specs_cpu=data[1]
      specs_os=data[2]
      specs_ram=data[3]
      specs_disk=data[4]
      specs_host=data[5]
      data_tuple=(server_ip,specs_host, specs_os,specs_cpu,specs_ram ,specs_disk ,date_time)
      sqlite_insert_data_multi_columns(dbname_with_path,sql_insert_SERVER_specs,data_tuple)

   ### *** LOG SERVER USAGE IN DB ***
   def Log_server_usage_in_db(self,dbname_with_path,data):

      date_time=get_date_time()
      server_ip=data[0]
      specs_cpu_usage=data[1]
      specs_disk_usage=data[2]
      specs_memory_usage=data[3]
      specs_process_usage=data[4]
      data_tuple=(server_ip, specs_memory_usage, specs_cpu_usage,specs_disk_usage,specs_process_usage ,date_time)
      
      sqlite_insert_data_multi_columns(dbname_with_path,sql_insert_SERVER_usage,data_tuple)

   ### *** LOG_SERVER_HEALTH_IN_DB ***
   def Log_server_health_in_db(self,dbname_with_path,data):

      date_time=get_date_time()
      
      server_ip=data[0]
      specs_ping=data[1]
      specs_uptime=data[2]
      data_tuple=(server_ip, specs_ping, specs_uptime ,date_time) 
      
      sqlite_insert_data_multi_columns(dbname_with_path,sql_insert_SERVER_health,data_tuple)

   ### *** LOG URL STATUS IN DB *** 
   def Log_url_status_in_db(self,dbname_with_path,data):

      date_time=get_date_time()
      url=data[1]
      url_status=data[1]
      url_error=data[2] 
      data_tuple=( url, url_status ,url_error,date_time)
      sqlite_insert_data_multi_columns(dbname_with_path,sql_insert_URL_status,data_tuple)

   ### *** Log DB ROW COUNT IN DB *** 
   def Log_db_row_count_in_db(self,dbname_with_path,data):

      date_time=get_date_time()
      server=data[0] 
      dbpath=data[1]
      rowcount=data[2]
      
      data_tuple=( server,dbpath, rowcount ,date_time)
      sqlite_insert_data_multi_columns(dbname_with_path,sql_insert_DB_row_count,data_tuple)

   ### *** Get ROWs FROM TABLE IN DB  ***
   def Get_rows_from_dbtable(self,server,dbname_with_path,table,limit):
     
    idcolumn=table+"_id"
    #dbname_with_path=os.path.abspath(dbname_with_path) 
     
    command =f"sqlite3 {dbname_with_path} <<'END_SQL'\n"
    command+=".timeout 2000\n"
    command+="SELECT * FROM "+table+" order by "+idcolumn+" DESC limit 0,"+limit+" ;\n"
    command+="END_SQL"  
    response=run_server_command(server,command)
    
    return response