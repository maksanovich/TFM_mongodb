import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from plg_CENTOS.plg_c_System_info import *
#from plg_TFM.plg_SSH import * #plg_CENTOS already contain ssh
from plg_CUSTOM.plg_Server_info import *  
from core_TASK.core_Sqlite import * 
from plg_TFM.plg_TXT import * 


class Server_specs:
   
   def Log_server_specs(self,server_ip, SSH_username, SSH_password): 
      LIST_server_specs=[]
      server =SSH_into_server(server_ip, SSH_username, SSH_password)
      if server:
         SqliteTasksObj= Sqlite_tasks() 
         dbname=SqliteTasksObj.Setup_log_db('/DB_check_server/','server_specs')
          
         cpu_specs=self._FetchLog_cpu_specs(server) 
         os_specs=self._FetchLog_os_specs(server)
         ram_specs=self._FetchLog_ram_specs(server) 
         disk_specs=self._FetchLog_disk_specs(server)
         host_specs=self._FetchLog_host_specs(server)
         LIST_server_specs=[server_ip,cpu_specs,os_specs,ram_specs,disk_specs,host_specs,dbname]
         SqliteTasksObj.Log_server_specs_in_db(dbname,LIST_server_specs) 
             
      return LIST_server_specs

   def _FetchLog_cpu_specs(self,server): 
      ip_infos= server.get_transport().getpeername() #return tuple
      server_ip=ip_infos[0]   
      command=get_specs_CPU("0") 
      cpu_specs=run_server_command(server,command) 
            
      file_name=server_ip+'_cpu_specs.txt'
      log_cpu_specs_text_file = FOLDER_PATH_RAW +  'RAW_check_server/' +  file_name 
               
      delete_TXT_file(log_cpu_specs_text_file)           
      date_time=get_date_time()
      content='Log Time : '+str(date_time)+'\n' 
      LIST_content=[content,cpu_specs]
      write_to_TXT_file_2(log_cpu_specs_text_file,LIST_content) 

      return cpu_specs

   def _FetchLog_os_specs(self,server):  
      ip_infos= server.get_transport().getpeername() #return tuple
      server_ip=ip_infos[0]  
      command=get_specs_OS("0") 
      os_specs=run_server_command(server,command)
      file_name=server_ip+'_os_specs.txt'
      log_os_specs_text_file = FOLDER_PATH_RAW +  'RAW_check_server/' +  file_name 
               
      delete_TXT_file(log_os_specs_text_file)           
      date_time=get_date_time()
      content='Log Time : '+str(date_time) +'\n' 
      LIST_content=[content,os_specs]
      write_to_TXT_file_2(log_os_specs_text_file,LIST_content)

      return os_specs
   
   def _FetchLog_ram_specs(self,server):  
      ip_infos= server.get_transport().getpeername() #return tuple
      server_ip=ip_infos[0]  
      command=get_specs_RAM("0")
      ram_specs=run_server_command(server,command) 
      ram_specs=ram_specs.replace('*-','')

      file_name=server_ip+'_ram_specs.txt'
      ram_specs_specs_text_file = FOLDER_PATH_RAW +  'RAW_check_server/' +  file_name 
               
      delete_TXT_file(ram_specs_specs_text_file)           
               
      date_time=get_date_time()
      content='Log Time : '+str(date_time) +'\n' 
      LIST_content=[content,ram_specs]
      write_to_TXT_file_2(ram_specs_specs_text_file,LIST_content)

      return ram_specs

   def _FetchLog_disk_specs(self,server):
      ip_infos= server.get_transport().getpeername() #return tuple
      server_ip=ip_infos[0] 
      command=get_specs_DISK("0")
      disk_specs=run_server_command(server,command) 
      file_name=server_ip+'_disk_specs.txt'
      disk_specs_text_file = FOLDER_PATH_RAW +  'RAW_check_server/' +  file_name 
               
      delete_TXT_file(disk_specs_text_file) 
      date_time=get_date_time()
            
      content='Log Time : '+str(date_time)+'\n'  
      LIST_content=[content,disk_specs]
      write_to_TXT_file_2(disk_specs_text_file,LIST_content)
      return disk_specs

   def _FetchLog_host_specs(self,server):
      ip_infos= server.get_transport().getpeername() #return tuple
      server_ip=ip_infos[0] 
      command=get_specs_HOST("0") 
      host_specs=run_server_command(server,command)
      file_name=server_ip+'_host_specs.txt'
      host_specs_text_file = FOLDER_PATH_RAW +  'RAW_check_server/' +  file_name 
               
      delete_TXT_file(host_specs_text_file)
      date_time=get_date_time()
      content='Log Time : '+str(date_time)+'\n'  
      LIST_content=[content,host_specs]
      write_to_TXT_file_2(host_specs_text_file,LIST_content)
      return host_specs
