import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from plg_CUSTOM.plg_Server_info import * 
from core_TASK.core_Server_specs import * 
from core_TASK.core_Server_health import *
from core_TASK.core_Server_usage import *
from plg_TFM.plg_CSV import * 

class Check_server:
   
   def Log_check_server(self,csv_path):
    
      if os.path.exists(csv_path)==True:
         Dir_path = os.path.dirname(os.path.abspath(__file__))
         cron_command_directory=os.path.dirname(Dir_path)
         cron_command_file=cron_command_directory+"/TFM_task_router.py"
         cron_task_function='Schedule_check_server'
         args='a_0'+csv_path
            
         Setup_cronjob_byminutes(cron_command_file,cron_task_function,args,LOG_CHECK_SERVER_INTERVAL,'ScheduleCheckServer')
      else:
         print("csv path is wrong") 

   ### *** SCHEDULE LOG SERVER ***  
   def Schedule_check_server(self,csv_path): 
      if os.path.exists(csv_path)==True:
         infoLIST=CSV_reader(csv_path)
         for i in range(len(infoLIST)):
            if i>0 :
               row_string= infoLIST[i][0] 
               arr=row_string.split(',')
               server_batch_num= arr[0]
               server_type= arr[1]
               server_ip= arr[2]
               SSH_username= arr[3]
               SSH_password= arr[4]
                  
               ServerSpecsObj = Server_specs()
               ServerSpecsObj.Log_server_specs(server_ip,SSH_username,SSH_password)
                  
               ServerHealthObj = Server_health()
               ServerHealthObj.Log_server_health(server_ip,SSH_username,SSH_password)
                  
               ServerUsagerObj = Server_usage()
               ServerUsagerObj.Log_server_usage (server_ip,SSH_username,SSH_password)
      else:
         print("csv file not found in Schedule_check_server") 
   
    



