import sys
import os
import requests

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from plg_CUSTOM.plg_Server_info import * 
from core_TASK.core_Sqlite import * 
from core_TASK.core_Alert_email import * 
from plg_TFM.plg_TXT import * 

class URL_status:
   
   def Log_url_status(self,urls_file_path):
      Dir_path = os.path.dirname(os.path.abspath(__file__))
      cron_command_directory=os.path.dirname(Dir_path)
      cron_command_file=cron_command_directory+"/TFM_task_router.py"
      cron_task_function='Schedule_url_status'
      args='a_0'+urls_file_path+'a_1'
      
      url_status_text_file=''
      if os.path.exists(urls_file_path)==True:
         file_name=urls_file_path.replace('.txt','_status.txt')  
         file_name=os.path.basename(file_name)
         url_status_text_file = FOLDER_PATH_RAW +  'RAW_check_url/' +  file_name 

      Setup_cronjob_byminutes(cron_command_file,cron_task_function,args,LOG_URL_STATUS_INTERVAL,'ScheduleUrlStatus')
      return url_status_text_file
    
   ### *** SCHEDULE URL STATUS ***
   def Schedule_url_status (self,urls_file_path):
      
      if os.path.exists(urls_file_path)==True: # if this file exists it means schedular is already running 
       
         List_urls = read_TXT_file(urls_file_path)
         SqliteTasksObj= Sqlite_tasks()
         dbname=SqliteTasksObj.Setup_log_db("/DB_check_url/",'url_status')
         file_name=urls_file_path.replace('.txt','_status.txt')  
         file_name=os.path.basename(file_name)
         url_status_text_file = FOLDER_PATH_RAW +  'RAW_check_url/' +  file_name 
         delete_TXT_file(url_status_text_file)          
         date_time=get_date_time()
         content='Log Time : '+str(date_time)+'\n' 
         LIST_content=[content,'Logged in Db : '+dbname+'\n']
         write_to_TXT_file_2(url_status_text_file,LIST_content)
         
         # Strips the newline character
         for line in List_urls:
               url=  line.strip()
               urlcontent='URL : '+url+ '\n' 
               write_to_TXT_file_1(url_status_text_file,urlcontent)
               try:
                  r = requests.head(url)
                  status_code=r.status_code
                  output=[url,status_code,'']
                  status_content=  'status : ' + str(status_code)+'\n\n\n'
                  
                  write_to_TXT_file_1(url_status_text_file,status_content)
                  SqliteTasksObj.Log_url_status_in_db(dbname,output)
               
               except requests.ConnectionError as e: 
                  error="OOPS!! Connection Error. Make sure you are connected to Internet. Technical Details given below.\n"
                  
                  error+=str(e)
                  print(error)
                  
                  error_content=  'Error : ' + error +'\n\n\n'
                  LIST_content=error_content.splitlines()
                  
                  write_to_TXT_file_2(url_status_text_file,LIST_content)
                  output=[url,status_code,error]
                  SqliteTasksObj.Log_url_status_in_db(dbname,output)
                  msg = "Subject: ERROR URL => " + str(url)
                  self._Send_Alert_Emails(msg)
                  continue
               except requests.Timeout as e:
                  error="OOPS!! Timeout Error"
                  error+=str(e)
                  print(error)
                  error_content=  'Error : ' + error +'\n\n\n'
                  LIST_content=error_content.splitlines()
                  write_to_TXT_file_2(url_status_text_file,LIST_content)
                  output=[url,status_code,error]
                  SqliteTasksObj.Log_url_status_in_db(dbname,output)
                  msg = "Subject: ERROR URL => " + str(url)
                  self._Send_Alert_Emails(msg)
                  continue
               except requests.RequestException as e:
                  error="OOPS!! General Error"
                  error+=str(e)
                  print(error)
                  error_content=  'Error : ' + error +'\n\n\n'
                  LIST_content=error_content.splitlines()
                  
                  write_to_TXT_file_2(url_status_text_file,LIST_content) 
                  output=[url,status_code,error]
                  SqliteTasksObj.Log_url_status_in_db(dbname,output) 
                  msg = "Subject: ERROR URL => " + str(url)
                  self._Send_Alert_Emails(msg) 
                  continue  
               except KeyboardInterrupt:
                  error="Someone closed the program"
                  error+=str(e)
                  print(error)
                  error_content=  'Error : ' + error +'\n\n\n'
                  LIST_content=error_content.splitlines()
                  write_to_TXT_file_2(url_status_text_file,LIST_content)
                  output=[url,status_code,error]
                  SqliteTasksObj.Log_url_status_in_db(dbname,output) 
                  msg = "Subject: ERROR URL => " + str(url)
                  self._Send_Alert_Emails(msg)
                  print('\n')
                  continue
                  
   def _Send_Alert_Emails(self,msg):
      AlertEmailObj=Alert_email()
      try :
                 
         AlertEmailObj.ALERT_Ym_sf6684()[0].sendmail(from_sf6684, "sf6684@yahoo.com", msg)
         AlertEmailObj.ALERT_Aol_shanef1788()[0].sendmail(from_aol_shanef1788, "sf6684@yahoo.com", msg)
         AlertEmailObj.ALERT_Aol_shanef1788()[0].sendmail(from_aol_shanef1788, "shanef1788@aol.com", msg)
      except Exception as e:
          print  ( f'Alert Email failed : {str(e)} '  )      

