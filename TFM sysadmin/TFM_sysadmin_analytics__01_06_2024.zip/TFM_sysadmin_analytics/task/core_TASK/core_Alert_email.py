import sys
import os
import smtplib
from email.mime.text import MIMEText
sys.path.append('../plg_CUSTOM/') 
sys.path.append('../plg_TFM/') 

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from plg_CUSTOM.plg_Alert_email import * 

class Alert_email:

    def ALERT_Ym_sf6684 (self):

        to_email = 'sf6684@yahoo.com' #Send email to myself to save email usage??

        ####Must disable or de-activate yahoo account keys 
        server = smtplib.SMTP(yahoo_host_SMTP, 587)
        server.starttls()
        server_login = server.login(user_sf6684, app_pass)
        
        #server.sendmail(from_sf6684, to_email, msg_yahoo)
        #print ('email sent to => ' + to_email )
        
        return server, server_login 

    def ALERT_Aol_shanef1788 (self):

        to_email_list = ['sf6684@yahoo.com', 'shanef1888@gmail.com', 'shanef1788@aol.com']

        ####Must disable or de-activate AOL account keys 
        server = smtplib.SMTP(aol_host_SMTP, 587)
        server.starttls()
        server_login = server.login(user_aol_shanef1788, aol_app_pass)
        
        return server, server_login
        
        #for to_email in to_email_list:
        
        #server.sendmail(from_aol_shanef1788, to_email, msg_aol)
        #print ('email sent to => ' + to_email )
        
                
    #ALERT_Aol_shanef1788 ()