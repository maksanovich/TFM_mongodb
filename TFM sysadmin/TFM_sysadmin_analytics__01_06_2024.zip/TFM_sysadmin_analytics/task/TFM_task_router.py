
#must append ALL folder paths of the files to be imported and used
import sys

sys.path.append('core_TASK/')
sys.path.append('plg_CUSTOM/') 
sys.path.append('plg_TFM/')

from core_Server_specs import *
from core_Server_health import *
from core_Server_usage import *
from core_Check_server import *
from core_URL_status import *
from core_Db_data import *
from core_Sqlite import *  


#https://www.codeproject.com/Questions/5339935/How-do-I-pass-multiple-variables-from-PHP-to-Python

#pass in the values from API_get_request
TFM_task = ''  
TFM_task_action = ''
    #sys.argv[0] is script file name so ignore
if len(sys.argv) > 1:
    TFM_task = sys.argv[1]  
if len(sys.argv) > 2:    
    TFM_task_action = sys.argv[2]   

#eg. http://12.242.23.23/TFM_task=TASK_1?TFM_task_action=a_0../data/raw/names.txta_1'david','peter','jon','lucy' 


 

# leave uncommented for testing of Log_server_specs ,Log_server_health ,Log_Server_usuage
 
#global server ip defined 
server_ip='173.208.150.146'
SSH_username='root'
SSH_password='V999zje4kksp!'   
  

# https://www.freecodecamp.org/news/python-switch-statement-switch-case-example/
def select_task ():
      
        if TFM_task== "Log_check_server":
            print("This is TASK - Log_check_server")
           
            # One parameter needs to be passed which csv file with full path containing server ssh info
            CSV_path = re.sub(r'^.*?a_0', '', TFM_task_action.partition("a_1")[0]).strip()
           
            serverObj = Check_server() 
            serverObj.Log_check_server(CSV_path)
         
        ### task Schedule_log_server
        elif TFM_task== "Schedule_check_server":
            print("This is Task - Schedule_check_server")
             
            CSV_path = re.sub(r'^.*?a_0', '', TFM_task_action.partition("a_1")[0]).strip()
            
            serverObj = Check_server() 
            serverObj.Schedule_check_server(CSV_path)
         ### task Log_check_server
        elif TFM_task== "Log_url_status":
            print("This is TASK - Log_url_status")
           
            # One parameter needs to be passed which txt file with full path containing url list  
            #python3 TFM_task_router.py Log_url_status a_0../data/raw/RAW_check_url/TFM_url_list_0.txt
            urls_txt_path = re.sub(r'^.*?a_0', '', TFM_task_action.partition("a_1")[0]).strip()
            serverObj = URL_status() 
            serverObj.Log_url_status(urls_txt_path)
         
        ### task Schedule_log_server
        elif TFM_task== "Schedule_url_status":
            print("This is Task - Schedule_url_status")
            urls_txt_path = re.sub(r'^.*?a_0', '', TFM_task_action.partition("a_1")[0]).strip()
            
            serverObj = URL_status() 
            serverObj.Schedule_url_status(urls_txt_path)  
            
        ### task Log db data
        elif TFM_task== "Log_db_data":
            print("This is Task - Log_db_data")
            # two parameter needs to be passed one csv file with full path and sqlite database file with full path 
            #python3 TFM_task_router.py Log_db_data a_0../data/raw/TFM_hosts_1.csva_1../data/raw/RAW_check_database/TFM_db_list_0.txt 
            csv_server_path = re.sub(r'^.*?a_0', '', TFM_task_action.partition("a_1")[0]).strip()
            db_txt_path = re.sub(r'^.*?a_1', '', TFM_task_action).strip() 
            serverObj = DB_data() 
            response=serverObj.Log_db_data(csv_server_path,db_txt_path) 
            print(response)
        ### task Schedule_log_db_data
        elif TFM_task== "Schedule_log_db_data":
            print("This is Task - Schedule_log_db_data")
            
            csv_server_path = re.sub(r'^.*?a_0', '', TFM_task_action.partition("a_1")[0]).strip()
            db_txt_path = re.sub(r'^.*?a_1', '', TFM_task_action).strip() 
            serverObj = DB_data() 
            serverObj.Schedule_log_db_data(csv_server_path,db_txt_path)     
        
        ### task Log_server_specs
        elif TFM_task== "Log_server_specs":
            print("This is TASK - Log_server_specs") #Task full name (Not abbreviated name)
            # command for calling this function with server info defined globally   python TFM_task_router.py Log_server_specs or 
            # python TFM_task_router.py Log_server_specs a_0173.208.150.146a_1roota_2V999zje4kksp! passing the values of your own
            serverObj = Server_specs()
               
            Server_ip_param = re.sub(r'^.*?a_0', '', TFM_task_action.partition("a_1")[0]).strip()
            SSH_username_param=re.sub(r'^.*?a_1', '', TFM_task_action.partition("a_2")[0]).strip()
            SSH_password_param = re.sub(r'^.*?a_2', '', TFM_task_action).strip()
            
            if Server_ip_param!='':
                LIST_server_specs=serverObj.Log_server_specs(Server_ip_param,SSH_username_param,SSH_password_param)
                print(LIST_server_specs)
            elif server_ip!=''  :
                LIST_server_specs=serverObj.Log_server_specs(server_ip,SSH_username,SSH_password)
                print(LIST_server_specs)
            else:
                print('Error!! Please provide SSh credentials')  
            
           
        ### task Log_server_health
        elif TFM_task== "Log_server_health":

            print("This is TASK - Log server health")
            # command for calling this function with server info defined globally   python TFM_task_router.py Log_server_health or 
            # python TFM_task_router.py Log_server_health a_0173.208.150.146a_1roota_2V999zje4kksp! passing the values of your own
            serverObj = Server_health()
               
            Server_ip_param = re.sub(r'^.*?a_0', '', TFM_task_action.partition("a_1")[0]).strip()
            SSH_username_param=re.sub(r'^.*?a_1', '', TFM_task_action.partition("a_2")[0]).strip()
            SSH_password_param = re.sub(r'^.*?a_2', '', TFM_task_action).strip()
            
            if Server_ip_param!='':
                LIST_health=serverObj.Log_server_health(Server_ip_param,SSH_username_param,SSH_password_param)
                print(LIST_health)
            elif server_ip!=''  :
                LIST_health=serverObj.Log_server_health(server_ip,SSH_username,SSH_password)
                print(LIST_health)
            else:
                print('Error!! Please provide SSh credentials')    
       
       ### task Log_Server_usuage
        elif TFM_task== "Log_server_usage":
            print("This is TASK - Log_Server_usage")
            # command for calling this function with server info defined globally   python TFM_task_router.py Log_server_usage or 
            # python TFM_task_router.py Log_server_usage a_0173.208.150.146a_1roota_2V999zje4kksp! passing the values of your own

            serverObj = Server_usage()  
            Server_ip_param = re.sub(r'^.*?a_0', '', TFM_task_action.partition("a_1")[0]).strip()
            SSH_username_param=re.sub(r'^.*?a_1', '', TFM_task_action.partition("a_2")[0]).strip()
            SSH_password_param = re.sub(r'^.*?a_2', '', TFM_task_action).strip()
            
            if Server_ip_param!='':
                LIST_server_usage=serverObj.Log_server_usage(Server_ip_param,SSH_username_param,SSH_password_param)
                #print(LIST_server_usage)
            elif server_ip!=''  :
                LIST_server_usage=serverObj.Log_server_usage(server_ip,SSH_username,SSH_password)
                #print(LIST_server_usage)
            else:
                print('Error!! Please provide SSh credentials')
         

        ### *** Get ROWs From table in db  ***
        elif TFM_task== "Get_rows_from_dbtable":
            dbname_with_path = re.sub(r'^.*?a_0', '', TFM_task_action.partition("a_1")[0]).strip()
            #table = re.sub(r'^.*?a_1', '', TFM_task_action).strip() 
            table=re.sub(r'^.*?a_1', '', TFM_task_action.partition("a_2")[0]).strip()
            row_number = re.sub(r'^.*?a_2', '', TFM_task_action).strip() 
            client=SSH_into_server(server_ip,SSH_username,SSH_password) 
            SqliteTasksObj=Sqlite_tasks()
            response=SqliteTasksObj.Get_rows_from_dbtable(client,dbname_with_path,table,row_number)
            
            print(response)
        elif TFM_task== "test":
            
            
            print("you are in now test")    
        else :
           print("Please input the name of task correctly")   
   

select_task ()