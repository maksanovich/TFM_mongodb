import platform
import subprocess
import os
import tempfile
import psutil 
import requests
import sqlite3
import sys
from crontab import CronTab
from datetime import datetime
from plg_CSV import * 
#from plg_SSH import * 

# variables for paths 
FOLDER_PATH_RAW='../data/raw/'
FOLDER_PATH_COOKED='../data/cooked/'

LOG_DB_DATA_INTERVEL=60
LOG_URL_STATUS_INTERVAL=5
LOG_CHECK_SERVER_INTERVAL=5

#sql script
TBL_create_Log_server_specs = 'CREATE TABLE IF NOT EXISTS Log_server_specs (Log_server_specs_id INTEGER PRIMARY KEY AUTOINCREMENT, server_ip VARCHAR, specs_HOST TEXT, specs_OS TEXT, specs_CPU TEXT , specs_RAM TEXT, specs_DISK TEXT , Logged_date_time VARCHAR)'
TBL_create_Log_server_usage = 'CREATE TABLE IF NOT EXISTS Log_server_usage(Log_server_usage_id INTEGER PRIMARY KEY AUTOINCREMENT,  server_ip VARCHAR, usage_RAM TEXT, usage_CPU TEXT, usage_DISK TEXT, usage_Processes TEXT, Logged_date_time VARCHAR )'
TBL_create_Log_server_health = 'CREATE TABLE IF NOT EXISTS Log_server_health(Log_server_health_id INTEGER PRIMARY KEY AUTOINCREMENT,  server_ip VARCHAR, ping_SERVER TEXT, uptime_SERVER TEXT, Logged_date_time VARCHAR )'
TBL_create_Log_url_status = 'CREATE TABLE IF NOT EXISTS Log_url_status(Log_url_status_id INTEGER PRIMARY KEY AUTOINCREMENT,  Url VARCHAR,  Url_status_code VARCHAR, Url_error TEXT, Logged_date_time VARCHAR )'
TBL_create_DB_row_count = 'CREATE TABLE IF NOT EXISTS Log_db_row_count(Log_db_row_count_id INTEGER PRIMARY KEY AUTOINCREMENT, server_ip VARCHAR,   dbWithPath VARCHAR,  rowCount VARCHAR,  Logged_date_time VARCHAR )'

sql_insert_SERVER_specs = "INSERT INTO Log_server_specs( server_ip, specs_HOST, specs_OS,specs_CPU,specs_RAM ,specs_DISK,Logged_date_time) VALUES (?,?,?,?,?,?,?)"
sql_insert_SERVER_usage = "INSERT INTO Log_server_usage( server_ip, usage_RAM , usage_CPU , usage_DISK , usage_Processes, Logged_date_time) VALUES (?,?,?,?,?,?)"
sql_insert_SERVER_health = "INSERT INTO Log_server_health( server_ip, ping_SERVER, uptime_SERVER, Logged_date_time) VALUES (?,?,?,?)"
sql_insert_URL_status = "INSERT INTO Log_url_status( Url, Url_status_code,Url_error, Logged_date_time) VALUES (?,?,?,?)"
sql_insert_DB_row_count = "INSERT INTO Log_db_row_count( server_ip,dbWithPath, rowCount,  Logged_date_time) VALUES (?,?,?,?)"

# Emails Settings
#RUN SERVER COMMAND  
def run_server_command (server,command):  
     if server:
        info=''
        try:
            stdin, stdout, stderr = server.exec_command(command)
            info=stdout.read().decode()
            
        except Exception as e:
            print(f"Error retrieving {command} : {e}")
        
        return info 

### *** GET DATE TIME ***    
def get_date_time ():
   # datetime object containing current date and time
   now = datetime.now()
   dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
    
   return dt_string 

    

### *** SETUP CRON JOB BY MINUTES ***    
 
def Setup_cronjob_byminutes( cron_command_file, cron_task_function,args, interval,job_name):
    os_name = platform.system()
    job_name =  job_name+"Every_"+str(interval)+"_Minutes"
                
    if os_name == 'Linux' or os_name == 'Darwin':
        cron_user=  os.environ.get('USER', os.environ.get('USERNAME'))
        #command=   PYTHON_EXE_PATH +' ' + cron_command_file+ ' ' + cron_task_function + ' ' +args 
        command=  'cd '+ os.path.dirname(cron_command_file) +' && python3'+' ' +  os.path.basename(cron_command_file)+ ' ' + cron_task_function + ' ' +args +' > /tmp/'+job_name+'.log 2>&1'
        # Unix-based systems (Linux, macOS)
         
        cron = CronTab(user=cron_user)
        # Remove any existing job with the same job_name to avoid duplicates
        cron.remove_all(comment=job_name)
        
        job = cron.new(command=command, comment=job_name)
        if interval <= 59:
            job.minute.every(interval)
        elif interval <= 1440:  # 1440 minutes in a day
            hours_interval = interval // 60
            job.hour.every(hours_interval)
            job.minute.on(0)  # Ensure job runs at the start of each hour
        else:
            days_interval = interval // 1440
            job.day.every(days_interval)
            job.hour.on(0)    # Ensure job runs at the start of each day
            job.minute.on(0)  # Ensure job run
        #job.minute.every(interval)
        cron.write()
        date_time=get_date_time()
        print(f'Cron job created: {job} at {date_time} ')

    elif os_name == 'Windows':
        cron_user=   os.getlogin()
        trigger = f"/SC MINUTE /MO {interval}"
        
        command = f"cd /d {os.path.dirname(cron_command_file)} && python {os.path.basename(cron_command_file)} {cron_task_function}"

        batch_file= os.path.dirname(cron_command_file) +"\\run_scheduler.bat" # this should be into same as 
        #args1=os.path.dirname(cron_command_file)
        args1=os.path.basename(cron_command_file)
        args2=cron_task_function
        args3=args
        command='"\\\"'+batch_file + '\\\" ' + args1 + ' ' + args2 +  ' ' + args3 +'"' 
        
        # Create the task
         
        create_task_command = f'schtasks /create /tn "{job_name}" /SC MINUTE /MO '+str(interval)+' /TR ' +command+' /RU '+cron_user

        # Windows Task Scheduler
        
        try:
            #subprocess.run(create_task_command,  text=True, check=True)
            if sys.version_info >= (3, 7):
                subprocess.run(create_task_command, capture_output=True, text=True, check=True)
            else:
                result = subprocess.run(create_task_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
                print(result.stdout.decode('utf-8'))
            print(f'Task Scheduler job created: {job_name}')
        except subprocess.CalledProcessError as e:
            print(f"Failed to create task: {e}")
    
    else:
        print(f"Unsupported OS: {os_name}")

