import os

###### SPECS & USAGE #####

##Speces - CPU
cmd_CPU_0 = 'lscpu'  #General CPU specs 
cmd_CPU_1 ='cat /proc/cpuinfo' #Each individual cpu core specs

##Specs - RAM
cmd_RAM_0 = 'sudo lshw -short -C memory' #RAM list summary
cmd_RAM_1 = 'dmidecode --type memory'   #Full RAM specs 
cmd_RAM_2 = 'grep MemTotal /proc/meminfo' #Total memory
cmd_RAM_3 = 'awk "'"/MemTotal/ {print $2}"'" /proc/meminfo'  #Total memory 

##Specs - DISK
cmd_DISK_0 = 'fdisk -l | grep Disk' #Total hard disk space 
cmd_DISK_1 ='lshw -short -C disk' #Disk specs summary

##Specs - OS
cmd_OS_0 = 'cat /etc/os-release' #Operating system specs

##Specs - HOST
cmd_HOST_0 = 'hostnamectl' #host machine info

##Specs - SOFTWARE
cmd_SOFT_0 = 'sudo yum list installed | wc -l'  #count the software installed
cmd_SOFT_1 = 'sudo yum list installed'  #list all software installed --> https://www.cyberciti.biz/faq/check-list-installed-packages-in-centos-linux/

##Usage - CPU
cmd_CPU_use_0 = 'top -b -n1'    #using 'top' wont work --> https://stackoverflow.com/questions/25101619/reading-output-of-top-command-using-paramiko
cmd_CPU_use_1 = 'ps -eo %cpu,comm --sort=-%mem | head -n 10'

##Usage - RAM
cmd_RAM_use_0 = 'free -h'   #Total free and used memory 
cmd_RAM_use_1 = 'ps -eo %mem,comm --sort=-%mem | head -n 10'  #TOP 10 MEMORY-CONSUMING PROCESSES

cmd_CPU_RAM_use_0 = 'ps -eo %cpu,%mem,comm --sort=-%mem | head -n 10' 

##Usage - DISK --> https://www.tecmint.com/find-top-large-directories-and-files-sizes-in-linux/
cmd_DISK_use_0 = 'df -H --output=source,size,used,avail'

cmd_DISK_use_1 = 'du -a /etc/ | sort -n -r | head -n 10' #TOP 10 DISK-CONSUMING PROCESSES

cmd_DISK_use_2 = 'df -h /' #total disk of the root directory 

#cmd_DISK_use_3 = 'df -h --output='size','pcent' /' #https://linuxiac.com/check-disk-space-linux/

cmd_DISK_use_4 = 'df -h -t ext4'  #https://www.howtogeek.com/409611/how-to-view-free-disk-space-and-disk-usage-from-the-linux-terminal/

###### SYSTEM & URL #####

##System - PING
cmd_Sys_0 = 'ping -c 10 ' #must have a space after ping. server_ip is a variable containing ip

##System - Uptime 
cmd_Sys_1 = 'uptime' #How long the machine has been up & running 

##Url - Exists

##Webpage - Exists 



###### DIRECTORY & FILE #####
#############################################################################################
##### SSH ####
path_ssh_allow = '/etc/hosts.allow'
path_ssh_deny = '/etc/hosts.deny'

##Directory - Exists

##Directory - Count & info
cmd_dir_0 = 'ls -lS /' #list folder size in bytes from large to small
cmd_dir_1 = 'ls -lS / --block-size=KB' #list file size in kb from large to small

info_etc_0 = 'ls -lS /etc/' #list file from large to small size
info_etc_1 = 'ls -lh /etc/' #list file from a to z


##Directory - Content
#cmd_DIR_0 = 'ls ' + dir_path  #list all files inside a directory 
#Check specific type of file --> https://stackoverflow.com/questions/3964681/find-all-files-in-a-directory-with-extension-txt-in-python

path_etc = '/etc/'


##File - Exists

##File - Count & other info


##File - Content
#Read file content via SSH + FTP --> https://stackoverflow.com/questions/1596963/read-a-file-from-server-with-ssh-using-python

#read config file from each server and ensure all config files have the same content
path_Haproxy_cfg = ''    
path_Galera_cfg = ''
path_host_allow = ''
path_host_deny = ''
path_Joomla_cfg = ''



#https://www.tecmint.com/ss-command-examples-in-linux/
##### NETWORK & PORT #####

##PORT - Status 


##### APP & SERVICE ##### (Include ports and network services)

#############################################################################################
#### Some important commands w.r.t. Linux OS ####


#############################################################################################
##### Python ####
python_version ='python --version'
python_3_version = 'python3 --version'


#############################################################################################
##### Docker ####
docker_help ='docker --help'
docker_install = ''
docker_container_list = 'docker ps'
docker_version = 'docker version'
docker_status = 'service docker status'
docker_start =''
docker_stop = ''
docker_restart =''


#############################################################################################
#### iptables ####
# iptables is a command not service. So, it will not provide the start, stop, status, etc... options.
# We can just enable/disable the firewall by using 'ufw' command
iptables_install="$SUDO $INSTALLER -y install iptables iptables-persistent"
ufw_install_for_centos_1="$SUDO $INSTALLER -y install epel-release"
ufw_install="$SUDO $INSTALLER -y install ufw"
iptables_version="iptables -V"
iptables_ufw_iptables_enable="$SUDO ufw --force enable"
iptables_ufw_iptables_disable="$SUDO ufw disable"
iptables_ufw_iptables_status="$SUDO ufw status"

#############################################################################################
#### Rsync ####
rsync_install="$SUDO $INSTALLER -y install rsync"
rsync_version="rsync --version"
rsync_start="$SUDO service rsync start"
rsync_stop="$SUDO service rsync stop"
rsync_status="$SUDO service rsync status"
rsync_restart="$SUDO service rsync restart"
rsync_mkdir_www="$SUDO mkdir -p /tmp/var/www"
rsync_local_backup="$SUDO rsync -avn /var/www /tmp/var/www"
rsync_remote_backup= ''
#rsync_grep_www="$SUDO grep -nri "/tmp/var/www" /etc/crontab"
rsync_mode_change="$SUDO chmod 0666 /etc/crontab"
rsync_mode_revert="$SUDO chmod 0644 /etc/crontab"
rsync_copy_rsyncd_conf="$SUDO cp /usr/share/doc/rsync/examples/rsyncd.conf /etc"

