

#######################################################
#### SMTP & IMAP - GMAIL ####
#######################################################

'''CODE EXAMPLES

https://www.pythonforbeginners.com/code-snippets-source-code/using-python-to-send-email

https://stackoverflow.com/questions/16512592/login-credentials-not-working-with-gmail-smtp

'''''
#Gmail global values 
gmail_host_SMTP = 'smtp.gmail.com'
gmail_host_IMAP = 'imap.gmail.com'
port_587 = '587'
port_465 = '465'

reply_to ='admin@eezyn.com'
bounce_to = 'admin@eezyn.com'


#Gmail accounts
 #shanef1788@gmail.com 
user_shanef1788 = 'shanef1788@gmail.com'
pass_shanef1788 = 'ff123???'
from_shanef1788 = 'shanef1788@gmail.com'
to = ''


#shanef1888@gmail.com 
user_shanef1888 = 'shanef1888@gmail.com'
pass_shanef1888 = 'ff123???'
from_shanef1888 = 'shanef1788@gmail.com'
to = ''

#sf16976@gmail.com 
user_sf16976 = "sf16976@gmail.com"
pass_sf16976 = "123ttqq89"
from_sf16976 = "sf16976@gmail.com"
to = ""

#sf64111@gmail.com
user_sf64111 = 'sf64111@gmail.com'
pass_sf64111 = '123ttqq89'
from_sf64111 = "sf64111@gmail.com"
to = ""


#######################################################
#### SMTP & IMAP - YAHOO ####
#######################################################


#Yahoo global values 
yahoo_host_SMTP = 'smtp.mail.yahoo.com'
yahoo_host_IMAP = 'imap.mail.yahoo.com'
port_SMTP = '587'
port_IMAP = ''

#sf6684@yahoo.com 
user_sf6684 = 'sf6684@yahoo.com'
pass_sf6684 = '1165ABBq'
from_sf6684 = 'sf6684@yahoo.com'
#password = input("Type your password and press enter:")
sf6684_app_pass = 'mlqt zbkw xnxa euck'


#######################################################
#### SMTP & IMAP - AOL ####
#######################################################

#AOL global values 
aol_host_SMTP = 'smtp.aol.com'
aol_host_IMAP = 'imap.aol.com'
port = '587'

reply_to ='admin@eezyn.com'
bounce_to = 'admin@eezyn.com'

#AOL accounts
 
#shanef1788@aol.com 
user_aol_shanef1788 = 'shanef1788@aol.com'
pass_aol_shanef1788 = '1165ABBq'
from_aol_shanef1788 = 'shanef1788@aol.com'
to = ''

user_aol_shanef1999 = 'shanef1999@aol.com'
pass_aol_shanef1999 = '1168343aaa'

#Log into Yahoo account --> Account security --> App password --> Must use App password instead of the normal Yahoo password 
#same as Yahoo --> https://stackoverflow.com/questions/62030011/allow-less-secure-app-access-in-yahoo-mail
aol_app_pass = 'pnjo sjoy ttbx tbvi'

#######################################################
#### SMTP & IMAP - EEZYN ####
#######################################################

#Server global values 
reply_to ='admin@eezyn.com'
bounce_to = 'admin@eezyn.com'
eezyn_host_SMTP = 'mail.eezyn.com'
eezyn_host_IMAP = 'mail.eezyn.com'
port_SMTP = '587'
port_IMAP = '7143'

#Eezyn accounts
 
#shanef1788@gmail.com 
user_Eezyn = 'admin@eezyn.com'
#pass_Eezyn = 'Zimbra@2017'
pass_Eezyn ='1234@admin123'
from_Eezyn = 'admin@eezyn.com'
to = ''


#######################################################
#### SMTP & IMAP - GMX ####
#######################################################

#Gmx global values 
gmx_host_SMTP = 'mail.gmx.com'
gmx_host_IMAP = 'imap.gmx.com'
port = '587'

reply_to ='admin@eezyn.com'
bounce_to = 'admin@eezyn.com'

#Gmx accounts
 
#shanef1788@gmx.com 
user_gmx_shanef1788 = 'shanef1788@gmx.com'
pass_gmx_shanef1788 = '1165ABBq'
from_gmx_shanef1788 = 'shanef1788@gmx.com'
to = ''

#######################################################
#### SMTP & IMAP - OUTLOOK ####
#######################################################

#Outlook global values 
outlook_host_SMTP = 'smtp-mail.outlook.com'
outlook_host_IMAP = 'imap-mail.outlook.com'
port = '587'

reply_to ='admin@eezyn.com'
bounce_to = 'admin@eezyn.com'

#Outlook accounts
 
#shanef779@outlook.com 
user_outlook_shanef779 = ''
pass_outlook_shanef779 = ''
from_outlook_shanef779 = ''
to = ''

#sf6689@outlook.com 
user_sf6689 = ''
pass_sf6689 = ''
from_sf6689 = ''
to = ''

#######################################################
#### SMTP & IMAP - YANDEX ####
#######################################################

#Yandex global values 
yandex_host_SMTP = 'smtp.yandex.com'
yandex_host_IMAP = 'imap.yandex.com'
port = '587'

reply_to ='admin@eezyn.com'
bounce_to = 'admin@eezyn.com'

#Yandex accounts
 
#shanef.f@yandex.com 
user_shanef_f = 'shanef.f@yandex.com '
pass_shanef_f = 'A111BB99'
from_shanef_f = 'shanef.f@yandex.com '
to = ''


#shanef117@yandex.com 
user_shanef117 = 'shanef117@yandex.com '
pass_shanef117 = 'A111BB99'
from_shanef117 = 'shanef117@yandex.com'
to = ''


app_pass = 'mlqt zbkw xnxa euck'
#######################################################
#### EMAIL MESSAGES FOR Alert TASKK ####
#######################################################

msg_gmail = """\
Subject: EEZYN.COM URL ERROR!!
Reply-to: admin@eezyn.com 


EEZYN.COM URL EORROR, please check Eezyn.com website!!

Do NOT reply this email!

"""


#Create a text/plain message
#For Yahoo reply to must be set in the message text as --> Reply-to:
msg_yahoo = """\
Subject: EEZYN.COM URL ERROR!!
Reply-to: admin@eezyn.com 


EEZYN.COM URL EORROR, please check Eezyn.com website!!

Do NOT reply this email!

"""

#Reply to different email doesn't seem to work with AOL
msg_aol = """\
Subject: EEZYN.COM URL ERROR!!
Reply-to address: admin@eezyn.com


EEZYN.COM URL EORROR, please check Eezyn.com website!!

Do NOT reply this email!

"""

msg_eezyn = """\
Subject: EEZYN.COM URL ERROR!!



EEZYN.COM URL EORROR, please check Eezyn.com website!!

Do NOT reply this email!

"""




 