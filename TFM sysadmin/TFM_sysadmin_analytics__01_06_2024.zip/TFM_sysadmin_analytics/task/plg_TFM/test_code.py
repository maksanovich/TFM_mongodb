
 
 
 
def Multiproc ():
 
   p0 = Process(shane_func_0)
   p0.start()
 
   p1 = Process(shane_func_1)
   p1.start()
 
   p2 = Process(shane_func_2)
   p2.start()
 
   p3 = Process(shane_func_3)
   p3.start()
 
   p4 = Process(shane_func_4)
   p4.start()
 
   p5 = Process(shane_func_5)
   p5.start()
 
   p6 = Process(shane_func_6)
   p6.start()
 
   p7 = Process(shane_func_7)
   p7.start()
 
   p8 = Process(shane_func_8)
   p8.start()
 
   p9 = Process(shane_func_9)
   p9.start()
 
