

# https://raspberrypi.stackexchange.com/questions/15338/how-to-use-python-to-run-php


# https://copyprogramming.com/howto/how-to-run-php-in-python