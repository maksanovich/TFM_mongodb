
# https://thepythoncode.com/article/using-speech-recognition-to-convert-speech-to-text-python